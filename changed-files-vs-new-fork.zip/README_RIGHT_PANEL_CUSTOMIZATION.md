# AWS Lex Web UI Customization README

This document explains the customization work done on top of the original `aws-samples/aws-lex-web-ui` repository, with a focus on:

- Right-side floating panel UX
- PII onboarding flow (first name, last name, email, terms)
- Toolbar/status/quick-reply customization
- Build and local runtime adjustments

It also serves as a migration guide to replicate the same experience in a fresh fork.

---

## 1) What was changed at a high level

Compared to the original repository, this project now behaves like a productized assistant panel:

- The bot opens as a polished right-side floating panel
- A pre-chat onboarding form can be shown before normal chat
- Terms and services can be opened inside the onboarding experience
- Quick replies appear as chips above the input area
- Toolbar includes branded status details (for example, `Online` + indicator)
- Build and server flow are tuned to reliably serve these custom assets locally

---

## 2) File-by-file change map

### A. Page entry / host pages

#### `src/website/right-panel.html`
- Added full page shell and right floating iframe styles
- Uses fetch-based config loading (`lex-web-ui-loader-config.json`)
- Forces same-origin parent/iframe setup
- Starts panel expanded by default

**Impact:** This file defines the final right-panel look and startup behavior.

#### `src/website/parent.html`
- Can be kept as debug page or adapted to right-panel style
- Uses iframe loader integration

**Impact:** If kept in debug mode, it shows diagnostics panels; if aligned with right-panel shell, it matches the clean production-like UI.

#### `src/website/custom-chatbot-style.css`
- Added active custom styling for toolbar, messages, quick replies, and input area

**Impact:** Controls branding and visual theme inside chatbot UI.

---

### B. Runtime config

#### `src/config/lex-web-ui-loader-config.json`
- Contains Cognito, Lex bot, UI, and iframe settings
- Adds onboarding labels, quick replies, toolbar status options, etc.

**Impact:** Main runtime switchboard for behavior and text. Missing/incorrect values cause startup issues or degraded UX.

---

### C. Lex UI components (inside iframe app)

#### `lex-web-ui/src/components/OnboardingForm.vue` (custom/new)
- PII form fields
- Terms link + in-panel terms content
- Validation and completion events

**Impact:** Pre-chat onboarding UX users see first when enabled.

#### `lex-web-ui/src/components/LexWeb.vue`
- Integrates onboarding and quick replies into core app flow
- Controls transition from onboarding to chat
- Sets onboarding-derived session attributes
- Adjusts layout when quick-reply strip is visible

**Impact:** Core behavior orchestration for onboarding-to-chat experience.

#### `lex-web-ui/src/components/DefaultQuickReplies.vue` (custom/new)
- Renders default quick-reply chips
- Sends selected values as user messages

**Impact:** Guided interaction shortcuts for common intents.

#### `lex-web-ui/src/components/ToolbarContainer.vue`
- Branded header layout
- Status line support (for example, `Online`)
- Default avatar behavior and configurable minimize icon

**Impact:** Final toolbar branding and controls.

#### `lex-web-ui/src/config/index.js`
- Adds defaults for onboarding, quick replies, toolbar status/avatar/icon values

**Impact:** Prevents undefined behavior when optional config values are not provided.

---

### D. Loader and embed behavior

#### `src/dependencies/initiate-loader.js`
#### `src/lex-web-ui-loader/js/defaults/loader.js`
- Adjusted embedded config behavior so iframe mode still receives full config

**Impact:** Avoids config loss when running embedded.

#### `src/lex-web-ui-loader/js/lib/iframe-component-loader.js`
- Hardened minimize state persistence logic (safer key handling)

**Impact:** Reduces edge-case failures in localStorage/minimize state restore.

---

### E. Build + serve pipeline

#### `build/copy-assets.js`
- Ensures right-panel and website assets are copied to `dist`

**Impact:** Without this, output may not reflect source custom pages.

#### `lex-web-ui/scripts/post-build-css.js`
- Improved CSS file handling across build output variations

**Impact:** More reliable CSS availability after builds.

#### `server.js`
- Serves local assets for right-panel usage

**Impact:** Enables local run path at `http://localhost:8000`.

#### `package.json` (root and `lex-web-ui/package.json`)
- Script/dependency adjustments to support current local workflow

**Impact:** Enables consistent local start/build behavior.

---

## 3) Required files to copy into a fresh fork

If replicating this customization in a newly forked repo, copy these source files:

- `src/website/right-panel.html`
- `src/website/custom-chatbot-style.css`
- `src/config/lex-web-ui-loader-config.json`
- `lex-web-ui/src/components/OnboardingForm.vue`
- `lex-web-ui/src/components/DefaultQuickReplies.vue`
- `lex-web-ui/src/components/LexWeb.vue`
- `lex-web-ui/src/components/ToolbarContainer.vue`
- `lex-web-ui/src/config/index.js`
- `src/dependencies/initiate-loader.js`
- `src/lex-web-ui-loader/js/defaults/loader.js`
- `src/lex-web-ui-loader/js/lib/iframe-component-loader.js`
- `build/copy-assets.js`
- `lex-web-ui/scripts/post-build-css.js`
- `server.js`
- `package.json`
- `lex-web-ui/package.json`

Note: Copy from `src`/component sources, not from `dist`, whenever possible.

---

## 4) Local run steps

From repo root:

```bash
cd lex-web-ui
npm install
npm run build-dist
cd ..
npm install
node build/copy-assets.js
npm start
```

Open:

- `http://localhost:8000/right-panel.html`

Optional:

- `http://localhost:8000/parent.html` (if maintained)

---

## 5) Common issues and fixes

### Issue: White/blank page
- Usually means missing or stale built assets.
- Re-run build and copy steps, then restart server.

### Issue: `missing cognito poolId config`
- `src/config/lex-web-ui-loader-config.json` has missing or wrong Cognito config.

### Issue: Bot loads but says "unable to process your message"
- UI is loaded, but Lex backend config/permissions are invalid.
- Verify bot ID, alias ID, locale, region, and IAM permissions.

### Issue: Quick-reply chips overlap input area
- Layout reservation and quick-reply strip height mismatch.
- Align values in:
  - `lex-web-ui/src/components/LexWeb.vue`
  - `lex-web-ui/src/components/DefaultQuickReplies.vue`

---

## 6) Notes on behavior

- Onboarding appears when `ui.showOnboardingForm` is `true`.
- Terms content behavior comes from `OnboardingForm.vue`.
- Closing onboarding emits `close` and maps to minimize/close behavior in `LexWeb.vue`.
- Quick replies are purely UI shortcuts; each sends configured `value` text to Lex.

---

## 7) Summary

This customization transforms the upstream sample into a branded right-panel assistant flow with onboarding and guided actions. The changes are spread across host page, runtime config, iframe components, loader behavior, and build pipeline; all parts are needed for full parity in a new fork.

